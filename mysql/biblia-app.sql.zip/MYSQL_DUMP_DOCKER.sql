-- phpMyAdmin SQL Dump
-- version 4.8.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 22-Jan-2019 às 00:18
-- Versão do servidor: 10.1.33-MariaDB
-- PHP Version: 7.2.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `biblia-app`
--
CREATE DATABASE IF NOT EXISTS `biblia-app` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin;
USE `biblia-app`;

-- --------------------------------------------------------

--
-- Estrutura da tabela `current_verse`
--

CREATE TABLE IF NOT EXISTS `current_verse` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bookId` int(11) NOT NULL,
  `book` varchar(1000) COLLATE utf8mb4_bin NOT NULL,
  `abbrev` varchar(50) COLLATE utf8mb4_bin NOT NULL,
  `chapter` int(11) NOT NULL,
  `verse` int(11) NOT NULL,
  `text` varchar(1000) COLLATE utf8mb4_bin NOT NULL,
  `version` varchar(1000) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Extraindo dados da tabela `current_verse`
--

INSERT INTO `current_verse` (`id`, `bookId`, `book`, `abbrev`, `chapter`, `verse`, `text`, `version`) VALUES
(2, 51, '1ª Tessalonicenses', '1ts', 3, 3, 'para que ninguém seja abalado por estas tribulações; porque vós mesmo sabeis que para isto fomos destinados;', 'aa');

-- --------------------------------------------------------

--
-- Estrutura da tabela `current_version`
--

CREATE TABLE IF NOT EXISTS `current_version` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Extraindo dados da tabela `current_version`
--

INSERT INTO `current_version` (`id`) VALUES
(1);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
