-- phpMyAdmin SQL Dump
-- version 4.8.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 19-Jan-2019 às 04:33
-- Versão do servidor: 10.1.33-MariaDB
-- PHP Version: 7.2.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `biblia-app`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `current_verse`
--

CREATE TABLE `current_verse` (
  `id` int(11) NOT NULL,
  `bookId` int(11) NOT NULL,
  `book` varchar(1000) COLLATE utf8mb4_bin NOT NULL,
  `abbrev` varchar(50) COLLATE utf8mb4_bin NOT NULL,
  `chapter` int(11) NOT NULL,
  `verse` int(11) NOT NULL,
  `text` varchar(1000) COLLATE utf8mb4_bin NOT NULL,
  `version` varchar(1000) COLLATE utf8mb4_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Extraindo dados da tabela `current_verse`
--

INSERT INTO `current_verse` (`id`, `bookId`, `book`, `abbrev`, `chapter`, `verse`, `text`, `version`) VALUES
(2, 17, 'Jó', 'job', 42, 16, 'Depois disso Jó viveu cento e quarenta anos; viu seus filhos e os descendentes deles até a quarta geração.', 'nvi');

-- --------------------------------------------------------

--
-- Estrutura da tabela `current_version`
--

CREATE TABLE `current_version` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Extraindo dados da tabela `current_version`
--

INSERT INTO `current_version` (`id`) VALUES
(3);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `current_verse`
--
ALTER TABLE `current_verse`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `current_verse`
--
ALTER TABLE `current_verse`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
